﻿using SharpGL;
namespace _19127451_Lab03

{
    public partial class Form1 : Form
    {
        Color colorUserColor;
        List<Shape> shapes = new List<Shape>();
        List<Point> listPoint = new List<Point>();
        Point pStart, pEnd, clickedPoint;
        bool draw = false;
        bool highLightClick = false;
        bool moveCheck = false, zoomCheck = false,rotateCheck=false;
        int shapeType;
        float strokeSize=2.0f;
        
        public Form1()
        {
            InitializeComponent();
            colorUserColor = Color.White;
        }
        private void openGLControl_OpenGLInitialized(object sender, EventArgs e)
        {
            // Get the OpenGL object.
            OpenGL gl = openGLControl.OpenGL;
            // Set the clear color.
            gl.ClearColor(0, 0, 0, 0);
            // Set the projection matrix.
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            // Load the identity.
            gl.LoadIdentity();
        }

        private void openGLControl_OpenGLDraw(object sender, SharpGL.RenderEventArgs args)
        {
            
            OpenGL gl = openGLControl.OpenGL;
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0, 0);
            gl.Clear(SharpGL.OpenGL.GL_COLOR_BUFFER_BIT | SharpGL.OpenGL.GL_DEPTH_BUFFER_BIT);
            // vẽ lại các shape
            for (int i = 0; i < shapes.Count; i++) {
                shapes[i].setColor(colorUserColor);
                shapes[i].DrawShape(gl, strokeSize); 
            }
            if (draw == true)
            {
                if (shapeType == 1)
                {
                    Line line = new Line(pStart, pEnd, strokeSize, colorUserColor);
                    shapes.Add(line);
                }
                if (shapeType == 2) {
                    Circle circle = new Circle(pStart,pEnd, strokeSize, colorUserColor);
                    shapes.Add(circle);
                }
                if (shapeType == 3) { 
                    Ellipse ellipse= new Ellipse(pStart,pEnd, strokeSize, colorUserColor);
                    shapes.Add(ellipse);
                }
                if (shapeType == 4)
                {
                    Rectangle rectangle = new Rectangle(pStart, pEnd, strokeSize, colorUserColor);
                    shapes.Add(rectangle);
                }
                if (shapeType == 5)
                {
                    Square square = new Square(pStart, pEnd, strokeSize, colorUserColor);
                    shapes.Add(square);
                }
                if (shapeType == 6)
                {
                    Pentagon pentagon = new Pentagon(pStart, pEnd, strokeSize, colorUserColor);
                    shapes.Add(pentagon);
                }
                if (shapeType == 7)
                {
                    Hexagon hexagon = new Hexagon(pStart, pEnd, strokeSize, colorUserColor);
                    shapes.Add(hexagon);
                }
                if (shapeType == 8)
                {
                    if (listPoint.Count == 2)
                    {
                        Polygon polygon = new Polygon(listPoint);
                        shapes.Add(polygon);
                    }
                    else if (listPoint.Count > 2) {
                        shapes.RemoveAt(shapes.Count - 1);
                        Polygon polygon = new Polygon(listPoint);
                        shapes.Add(polygon);
                    }
                }

            }


        }
            
        private void openGLControl_Resized(object sender, EventArgs e)
        {
            // Get the OpenGL object.
            OpenGL gl = openGLControl.OpenGL;
            // Set the projection matrix.
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            // Load the identity.
            gl.LoadIdentity();
            // Create a perspective transformation.
            gl.Viewport(0, 0, openGLControl.Width, openGLControl.Height);
            gl.Ortho2D(0, openGLControl.Width, 0, openGLControl.Height);
        }
        private void openGLControl_MouseDown(object sender, MouseEventArgs e)
        {
            draw = false;
            if (e.Button == MouseButtons.Left)
            {
                pStart = e.Location;
                pEnd = pStart;
            }
        }
        private void openGLControl_MouseUp(object sender, MouseEventArgs e)
        {
            draw = true;
            if (e.Button == MouseButtons.Left)
            {
                pEnd = e.Location;
            }

            if (moveCheck == true)
            {
                for (int i = 0; i < shapes.Count; i++)
                {
                    if (shapes[i].hightLightCheck)
                    {
                        shapes[i].TranslateShape(pStart, pEnd);
                    }
                }

            }
            if (zoomCheck == true)
            {
                for (int i = 0; i < shapes.Count; i++)
                {
                    if (shapes[i].hightLightCheck == true)
                    {
                        shapes[i].ZoomShape(pStart, pEnd);
                    }
                }
                
            }
            if (rotateCheck == true)
            {
                for (int i = 0; i < shapes.Count; i++)
                {
                    if (shapes[i].hightLightCheck == true)
                    {
                        shapes[i].RotateShape(pStart, pEnd);
                    }
                }

            }

        }

        private void colorButton_Click(object sender, EventArgs e)
        {
            // Change drawing color due to user's choice
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                colorUserColor = colorDialog1.Color;
            }
        }
        private void lineButton_Click(object sender, EventArgs e)
        {
            shapeType = 1;
            draw = false;
        }

        private void circleButton_Click(object sender, EventArgs e)
        {
            shapeType = 2;
            draw = false;
        }
        private void ellipseButton_Click(object sender, EventArgs e)
        {
            shapeType = 3;
            draw = false;
        }
        private void rectangleButton_Click(object sender, EventArgs e)
        {
            shapeType = 4;
            draw = false;
        }
        private void squareButton_Click(object sender, EventArgs e)
        {
            shapeType = 5;
            draw = false;
        }
        private void pentagonButton_Click(object sender, EventArgs e)
        {
            shapeType = 6;
            draw = false;
        }
        private void hexagonButton_Click(object sender, EventArgs e)
        {
            shapeType = 7;
            draw = false;
        }
        private void polygonButton_Click(object sender, EventArgs e)
        {
            shapeType = 8;
            draw = false;
        }
        private void clearScreenButton_Click(object sender, EventArgs e)
        {
            OpenGL gl = openGLControl.OpenGL;
            shapes.Clear();
            listPoint.Clear();
            // xóa hết các điểm highlight
            for (int i = 0; i < shapes.Count; i++)
            {
                shapes[i].clearHLP();
            }
            gl.Clear(SharpGL.OpenGL.GL_COLOR_BUFFER_BIT | SharpGL.OpenGL.GL_DEPTH_BUFFER_BIT);
        }

        private void moveButton_Click(object sender, EventArgs e)
        {
            rotateCheck = false;
            zoomCheck = false;
            moveCheck = true;
        }

        private void strokeSizeBox_TextChanged(object sender, EventArgs e)
        {
            TextBox objTextBox = (TextBox)sender;
            if (String.IsNullOrEmpty(strokeSizeBox.Text))
            {
                return;
            }
            else
            {
                bool flag = false;
                flag = float.TryParse(objTextBox.Text, out _);

                if (flag == true)
                {
                    strokeSize = float.Parse(objTextBox.Text);
                }
                if (flag == false)
                {
                    MessageBox.Show("stroke size must be a number!");
                }
            }
        }

        private void rotateButton_Click(object sender, EventArgs e)
        {
            moveCheck = false;
            zoomCheck = false;
            rotateCheck = true;
        }

        private void scaleButton_Click(object sender, EventArgs e)
        {
            moveCheck = false;
            rotateCheck = false;
            zoomCheck = true;
        }

        private void hlButton_Click(object sender, EventArgs e)
        {
            highLightClick = true;
            shapeType = 0;
        }

     
        private void openGLControl_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                clickedPoint = e.Location;
                if (shapeType == 8)
                    listPoint.Add(e.Location);
                if (highLightClick == true)
                {
                    if (shapeType == 0&&!moveCheck&&!zoomCheck)
                    {
                        for (int i = 0; i < shapes.Count; i++)
                        {
                            shapes[i].showHighLight(openGLControl.OpenGL, clickedPoint);
                        }
                    }
                    highLightClick=false;   
                }
            }
            if (e.Button == MouseButtons.Right) {
                listPoint.Clear();
                shapeType = 0;
                moveCheck = false;
                zoomCheck = false;
                rotateCheck = false;
            }
        }

    }
}