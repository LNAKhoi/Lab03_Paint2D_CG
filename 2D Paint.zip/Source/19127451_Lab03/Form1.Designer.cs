﻿namespace _19127451_Lab03
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openGLControl = new SharpGL.OpenGLControl();
            this.lineButton = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.colorButton = new System.Windows.Forms.Button();
            this.circleButton = new System.Windows.Forms.Button();
            this.hlButton = new System.Windows.Forms.Button();
            this.ellipseButton = new System.Windows.Forms.Button();
            this.clearScreenButton = new System.Windows.Forms.Button();
            this.rectangleButton = new System.Windows.Forms.Button();
            this.squareButton = new System.Windows.Forms.Button();
            this.pentagonButton = new System.Windows.Forms.Button();
            this.hexagonButton = new System.Windows.Forms.Button();
            this.polygonButton = new System.Windows.Forms.Button();
            this.moveButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.strokeSizeBox = new System.Windows.Forms.TextBox();
            this.scaleButton = new System.Windows.Forms.Button();
            this.rotateButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl)).BeginInit();
            this.SuspendLayout();
            // 
            // openGLControl
            // 
            this.openGLControl.DrawFPS = false;
            this.openGLControl.Location = new System.Drawing.Point(0, 116);
            this.openGLControl.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.openGLControl.Name = "openGLControl";
            this.openGLControl.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            this.openGLControl.RenderContextType = SharpGL.RenderContextType.DIBSection;
            this.openGLControl.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            this.openGLControl.Size = new System.Drawing.Size(1118, 531);
            this.openGLControl.TabIndex = 0;
            this.openGLControl.OpenGLInitialized += new System.EventHandler(this.openGLControl_OpenGLInitialized);
            this.openGLControl.OpenGLDraw += new SharpGL.RenderEventHandler(this.openGLControl_OpenGLDraw);
            this.openGLControl.Resized += new System.EventHandler(this.openGLControl_Resized);
            this.openGLControl.MouseClick += new System.Windows.Forms.MouseEventHandler(this.openGLControl_MouseClick);
            this.openGLControl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.openGLControl_MouseDown);
            this.openGLControl.MouseUp += new System.Windows.Forms.MouseEventHandler(this.openGLControl_MouseUp);
            // 
            // lineButton
            // 
            this.lineButton.BackColor = System.Drawing.Color.Salmon;
            this.lineButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lineButton.Location = new System.Drawing.Point(12, 12);
            this.lineButton.Name = "lineButton";
            this.lineButton.Size = new System.Drawing.Size(85, 43);
            this.lineButton.TabIndex = 1;
            this.lineButton.Text = "Line";
            this.lineButton.UseVisualStyleBackColor = false;
            this.lineButton.Click += new System.EventHandler(this.lineButton_Click);
            // 
            // colorButton
            // 
            this.colorButton.BackColor = System.Drawing.Color.Salmon;
            this.colorButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.colorButton.Location = new System.Drawing.Point(400, 61);
            this.colorButton.Name = "colorButton";
            this.colorButton.Size = new System.Drawing.Size(85, 43);
            this.colorButton.TabIndex = 2;
            this.colorButton.Text = "Color";
            this.colorButton.UseVisualStyleBackColor = false;
            this.colorButton.Click += new System.EventHandler(this.colorButton_Click);
            // 
            // circleButton
            // 
            this.circleButton.BackColor = System.Drawing.Color.Salmon;
            this.circleButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.circleButton.Location = new System.Drawing.Point(12, 61);
            this.circleButton.Name = "circleButton";
            this.circleButton.Size = new System.Drawing.Size(85, 43);
            this.circleButton.TabIndex = 3;
            this.circleButton.Text = "Circle";
            this.circleButton.UseVisualStyleBackColor = false;
            this.circleButton.Click += new System.EventHandler(this.circleButton_Click);
            // 
            // hlButton
            // 
            this.hlButton.BackColor = System.Drawing.Color.Salmon;
            this.hlButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.hlButton.Location = new System.Drawing.Point(292, 61);
            this.hlButton.Name = "hlButton";
            this.hlButton.Size = new System.Drawing.Size(102, 43);
            this.hlButton.TabIndex = 4;
            this.hlButton.Text = "HighLights";
            this.hlButton.UseVisualStyleBackColor = false;
            this.hlButton.Click += new System.EventHandler(this.hlButton_Click);
            // 
            // ellipseButton
            // 
            this.ellipseButton.BackColor = System.Drawing.Color.Salmon;
            this.ellipseButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ellipseButton.Location = new System.Drawing.Point(201, 61);
            this.ellipseButton.Name = "ellipseButton";
            this.ellipseButton.Size = new System.Drawing.Size(85, 43);
            this.ellipseButton.TabIndex = 5;
            this.ellipseButton.Text = "Ellipse";
            this.ellipseButton.UseVisualStyleBackColor = false;
            this.ellipseButton.Click += new System.EventHandler(this.ellipseButton_Click);
            // 
            // clearScreenButton
            // 
            this.clearScreenButton.BackColor = System.Drawing.Color.Salmon;
            this.clearScreenButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.clearScreenButton.Location = new System.Drawing.Point(491, 61);
            this.clearScreenButton.Name = "clearScreenButton";
            this.clearScreenButton.Size = new System.Drawing.Size(85, 43);
            this.clearScreenButton.TabIndex = 6;
            this.clearScreenButton.Text = "Clear";
            this.clearScreenButton.UseVisualStyleBackColor = false;
            this.clearScreenButton.Click += new System.EventHandler(this.clearScreenButton_Click);
            // 
            // rectangleButton
            // 
            this.rectangleButton.BackColor = System.Drawing.Color.Salmon;
            this.rectangleButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rectangleButton.Location = new System.Drawing.Point(103, 61);
            this.rectangleButton.Name = "rectangleButton";
            this.rectangleButton.Size = new System.Drawing.Size(92, 43);
            this.rectangleButton.TabIndex = 7;
            this.rectangleButton.Text = "Rectangle";
            this.rectangleButton.UseVisualStyleBackColor = false;
            this.rectangleButton.Click += new System.EventHandler(this.rectangleButton_Click);
            // 
            // squareButton
            // 
            this.squareButton.BackColor = System.Drawing.Color.Salmon;
            this.squareButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.squareButton.Location = new System.Drawing.Point(201, 12);
            this.squareButton.Name = "squareButton";
            this.squareButton.Size = new System.Drawing.Size(85, 43);
            this.squareButton.TabIndex = 8;
            this.squareButton.Text = "Square";
            this.squareButton.UseVisualStyleBackColor = false;
            this.squareButton.Click += new System.EventHandler(this.squareButton_Click);
            // 
            // pentagonButton
            // 
            this.pentagonButton.BackColor = System.Drawing.Color.Salmon;
            this.pentagonButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pentagonButton.Location = new System.Drawing.Point(103, 12);
            this.pentagonButton.Name = "pentagonButton";
            this.pentagonButton.Size = new System.Drawing.Size(92, 43);
            this.pentagonButton.TabIndex = 9;
            this.pentagonButton.Text = "Pentagon";
            this.pentagonButton.UseVisualStyleBackColor = false;
            this.pentagonButton.Click += new System.EventHandler(this.pentagonButton_Click);
            // 
            // hexagonButton
            // 
            this.hexagonButton.BackColor = System.Drawing.Color.Salmon;
            this.hexagonButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.hexagonButton.Location = new System.Drawing.Point(292, 12);
            this.hexagonButton.Name = "hexagonButton";
            this.hexagonButton.Size = new System.Drawing.Size(102, 43);
            this.hexagonButton.TabIndex = 10;
            this.hexagonButton.Text = "Hexagon";
            this.hexagonButton.UseVisualStyleBackColor = false;
            this.hexagonButton.Click += new System.EventHandler(this.hexagonButton_Click);
            // 
            // polygonButton
            // 
            this.polygonButton.BackColor = System.Drawing.Color.Salmon;
            this.polygonButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.polygonButton.Location = new System.Drawing.Point(400, 12);
            this.polygonButton.Name = "polygonButton";
            this.polygonButton.Size = new System.Drawing.Size(85, 43);
            this.polygonButton.TabIndex = 11;
            this.polygonButton.Text = "Polygon";
            this.polygonButton.UseVisualStyleBackColor = false;
            this.polygonButton.Click += new System.EventHandler(this.polygonButton_Click);
            // 
            // moveButton
            // 
            this.moveButton.BackColor = System.Drawing.Color.Salmon;
            this.moveButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.moveButton.Location = new System.Drawing.Point(491, 12);
            this.moveButton.Name = "moveButton";
            this.moveButton.Size = new System.Drawing.Size(85, 43);
            this.moveButton.TabIndex = 12;
            this.moveButton.Text = "Move";
            this.moveButton.UseVisualStyleBackColor = false;
            this.moveButton.Click += new System.EventHandler(this.moveButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(1006, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 15);
            this.label1.TabIndex = 13;
            this.label1.Text = "Stroke size";
            // 
            // strokeSizeBox
            // 
            this.strokeSizeBox.Location = new System.Drawing.Point(1006, 30);
            this.strokeSizeBox.Name = "strokeSizeBox";
            this.strokeSizeBox.Size = new System.Drawing.Size(100, 23);
            this.strokeSizeBox.TabIndex = 14;
            this.strokeSizeBox.TextChanged += new System.EventHandler(this.strokeSizeBox_TextChanged);
            // 
            // scaleButton
            // 
            this.scaleButton.BackColor = System.Drawing.Color.Salmon;
            this.scaleButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.scaleButton.Location = new System.Drawing.Point(582, 12);
            this.scaleButton.Name = "scaleButton";
            this.scaleButton.Size = new System.Drawing.Size(85, 43);
            this.scaleButton.TabIndex = 15;
            this.scaleButton.Text = "Scale";
            this.scaleButton.UseVisualStyleBackColor = false;
            this.scaleButton.Click += new System.EventHandler(this.scaleButton_Click);
            // 
            // rotateButton
            // 
            this.rotateButton.BackColor = System.Drawing.Color.Salmon;
            this.rotateButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.rotateButton.Location = new System.Drawing.Point(582, 61);
            this.rotateButton.Name = "rotateButton";
            this.rotateButton.Size = new System.Drawing.Size(85, 43);
            this.rotateButton.TabIndex = 16;
            this.rotateButton.Text = "Rotate";
            this.rotateButton.UseVisualStyleBackColor = false;
            this.rotateButton.Click += new System.EventHandler(this.rotateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1118, 647);
            this.Controls.Add(this.rotateButton);
            this.Controls.Add(this.scaleButton);
            this.Controls.Add(this.strokeSizeBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.moveButton);
            this.Controls.Add(this.polygonButton);
            this.Controls.Add(this.hexagonButton);
            this.Controls.Add(this.pentagonButton);
            this.Controls.Add(this.squareButton);
            this.Controls.Add(this.rectangleButton);
            this.Controls.Add(this.clearScreenButton);
            this.Controls.Add(this.ellipseButton);
            this.Controls.Add(this.hlButton);
            this.Controls.Add(this.circleButton);
            this.Controls.Add(this.colorButton);
            this.Controls.Add(this.lineButton);
            this.Controls.Add(this.openGLControl);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SharpGL.OpenGLControl openGLControl;
        private Button lineButton;
        private ColorDialog colorDialog1;
        private Button colorButton;
        private Button circleButton;
        private Button hlButton;
        private Button ellipseButton;
        private Button clearScreenButton;
        private Button rectangleButton;
        private Button squareButton;
        private Button pentagonButton;
        private Button hexagonButton;
        private Button polygonButton;
        private Button moveButton;
        private Label label1;
        private TextBox strokeSizeBox;
        private Button scaleButton;
        private Button rotateButton;
    }
}