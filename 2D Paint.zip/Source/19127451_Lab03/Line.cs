﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpGL;
namespace _19127451_Lab03
{
    public partial class Line:Shape
    {
        // Midpoint
        public Line(Point start, Point end, float strokeSize, Color c)
        {
      
            this.sPoint = start;
            this.ePoint = end;
            int stepX = 1, stepY = 1;
            int  x, y;
            int p = 0;
            // tính giá trị delta x, delta y
            int dx = ePoint.X - sPoint.X;
            int dy = ePoint.Y - sPoint.Y;
            // add điểm highlight points
            hlPoint.Add(start);
            hlPoint.Add(end);

            // tính trường hợp dx,dy
            if (dx < 0) {
                dx *= -1; 
                stepX = -1; 
            } 
            else { 
                stepX = 1; 
            }

            if (dy < 0) {
                dy *= -1;
                stepY = -1; 
            }
            else { 
                stepY = 1;
            }
            // gán điểm bắt đầu vẽ vào raster
            x =this.sPoint.X;
            y = this.sPoint.Y;
            Point raster=new Point(x,y);
            rasterPoints.Add(raster);

            // bắt đầu thuật toán midpoint, chia trường hợp
            if (dx > dy)
            {
                 p = 2*dy - dx;
                while (x != ePoint.X)
                {
                    if (p > 0)
                    {
                        y += stepY;
                        p += 2*dy - 2*dx;
                    }
                    else
                    {
                        p += dy + dy;
                    }
                    x += stepX;
                    Point temp = new Point(x, y);
                    rasterPoints.Add(temp);
                }
            }
            else
            {
                 p = 2*dx - dy;
                while (y != ePoint.Y)
                {
                    if (p > 0)
                    {
                        x += stepX;
                        p += 2*dx -2*dy;
                    }
                    else
                    {
                        p += 2*dx;
                    }
                    y += stepY;
                    Point temp = new Point(x, y);
                    rasterPoints.Add(temp);
                }
            }
            rasterPoints.Add(new Point(ePoint.X,ePoint.Y));
        }
        public override void showHighLight(OpenGL gl, Point clickedPoint)
        {
            for (int i = 0; i < rasterPoints.Count; i++)
            {
                if (distance(clickedPoint, rasterPoints[i]) <= Epsilon)
                {
                    hightLightCheck = true;
                    this.hlPoint.Add(sPoint);
                    this.hlPoint.Add(ePoint);
                    return;
                }
            }
        }
    }
}
