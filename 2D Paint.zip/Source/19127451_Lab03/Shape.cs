﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpGL;
namespace _19127451_Lab03
{
    public abstract class Shape
    {
        public Color c;
        public Point sPoint, ePoint;
        public float strokeSize;
        public List<Point> rasterPoints= new List<Point>();
        public List<Point> hlPoint= new List<Point>();
        public const double Epsilon = 8.854187817;
        public bool hightLightCheck=false;
        AffineTransform affine;
        public Shape() { }
        public Shape(Point start, Point end, float Stroke)
        {
            this.sPoint = start;
            this.ePoint = end;
            this.strokeSize = Stroke;
        }
        public void setColor(Color c) {
            this.c = c;
        }
        // hàm vẽ các shapes
        public virtual List<Point> DrawShape(OpenGL gl,float strokeSize) {
            gl.PointSize(strokeSize);
            gl.Begin(OpenGL.GL_POINTS);
            for (int i = 0; i < rasterPoints.Count; i++)
                gl.Vertex(rasterPoints[i].X, gl.RenderContextProvider.Height - rasterPoints[i].Y);
            gl.End();
            gl.Flush();
            if (hightLightCheck == true) {
                gl.Color(c.R / 255.0, c.G / 255.0, c.B / 255.0, 0);
                gl.PointSize(8);
                gl.Begin(OpenGL.GL_POINTS);
                for (int i = 0; i < hlPoint.Count; i++)
                {
                    gl.Vertex(hlPoint[i].X, gl.RenderContextProvider.Height - hlPoint[i].Y);
                }
                gl.End();
                gl.Flush();
            }
            return rasterPoints;
        }
        // hàm tính khoảng cách
        public double distance(Point start, Point end) {
            double distance = Math.Sqrt(Math.Pow((start.X - end.X), 2) + Math.Pow((start.Y - end.Y), 2));
            return distance;
        }
        // hàm hiện highlights - control points
        public virtual void showHighLight(OpenGL gl, Point clickedPoint) {
            if (rasterPoints == null)
            {
                return;
            }
            else {
                for (int i = 0; i < rasterPoints.Count; i++) {
                    if (distance(clickedPoint, rasterPoints[i]) <= Epsilon){
                        hightLightCheck = true;
                        return;
                    }
                }
                hightLightCheck = false;
            }
        }

        // Affine Transform
        public virtual void TranslateShape(Point start, Point end) { 
            affine= new AffineTransform(); 
            // dời vị trí điểm đầu, điểm cuối
            affine.Translate(end.X-start.X,end.Y-start.Y);
            for (int i = 0; i < rasterPoints.Count; i++)
            {
                // dời vị trí các điểm vẽ hình
                rasterPoints[i] = affine.Transform(rasterPoints[i]);
                // nếu có bật điểm highlight thì dời điểm highlight
                if (hightLightCheck == true&& i<hlPoint.Count) {
                    hlPoint[i] = affine.Transform(hlPoint[i]);
                }
            }

            // biến đổi 2 điểm đầu cuối.
            sPoint = affine.Transform(sPoint);
            ePoint = affine.Transform(ePoint);
        }
        // hàm zoom ảnh
        public virtual void ZoomShape(Point start, Point end) {
            affine = new AffineTransform();
            if (distance(sPoint, start) < distance(ePoint, start)) {
                Point temp;
                temp = sPoint;
                sPoint = ePoint;
                ePoint = temp;
            }
            // tính sx,sy
            double sx = (double)(end.X - sPoint.X) / (double)(start.X - sPoint.X);
            double sy = (double)(end.Y - sPoint.Y) / (double)(start.Y - sPoint.Y);
            // để khi scale vẫn giữ nguyên hình dạng hình, không bị biến dạng
            double maxS = Math.Max(sx, sy);
            // dời điểm đầu
            affine.Translate(-sPoint.X, -sPoint.Y);
            // scale lại điểm 
            affine.Scale(maxS, maxS);
            // dời về chỗ cũ
            affine.Translate(sPoint.X, sPoint.Y);
            for (int i = 0; i < rasterPoints.Count; i++)
            {   
                // dời vị trí các điểm vẽ hình
                rasterPoints[i] = affine.Transform(rasterPoints[i]);
                // nếu có bật điểm highlight thì dời điểm highlight
                if (i < hlPoint.Count)
                {
                    hlPoint[i] = affine.Transform(hlPoint[i]);
                }
            }
            // biến đổi 2 điểm đầu cuối.
            sPoint = affine.Transform(sPoint);
            ePoint = affine.Transform(ePoint);
        }
        // hàm xoay
        public virtual void RotateShape(Point Start, Point End ){
            if (distance(sPoint, Start) < distance(ePoint, Start))
            {
                Point temp;
                temp = sPoint;
                sPoint = ePoint;
                ePoint = temp;
            }
            affine = new AffineTransform();
            Point newStart = new Point(Start.X - sPoint.X, Start.Y - sPoint.Y);
            Point newEnd = new Point(End.X - sPoint.X, End.Y - sPoint.Y);
            // tính khoảng cách thay đổi
            double newStartDistance = distance(sPoint, Start);
            double  newEndDistance = distance(sPoint, End);
            // tính góc
            double angle = newStart.X *newEnd.X + newStart.Y * newEnd.Y;
            angle /= newStartDistance * newEndDistance;
            // chuyển sang arcCos
            double theta = Math.Acos(angle);
            if (newStart.X * newEnd.Y - newStart.Y * newEnd.X < 0)
                theta *=-1 ;
            // bắt đầu biến đổi
            affine.Translate(-sPoint.X, -sPoint.Y);
            affine.Rotate(theta);
            affine.Translate(sPoint.X, sPoint.Y);
            // biến đổi các điểm vẽ và highlight
            for (int i = 0; i < rasterPoints.Count; i++)
            {
                rasterPoints[i] = affine.Transform(rasterPoints[i]);
                if (i < hlPoint.Count)
                    hlPoint[i] = affine.Transform(hlPoint[i]);
            }
            sPoint = affine.Transform(sPoint);
            ePoint = affine.Transform(ePoint);
        }
        public bool isControlPoint(Point clickedPoint) {
            if (hlPoint == null)
            {
                return false;
            }
            else {
                for (int i = 0; i < hlPoint.Count; i++) {
                    if (distance(hlPoint[i], clickedPoint) > Epsilon) {
                        return true;
                    }
                }
            }
            return false;
        }
        public void clearHLP() {
            hlPoint.Clear();
        }
    }
}
