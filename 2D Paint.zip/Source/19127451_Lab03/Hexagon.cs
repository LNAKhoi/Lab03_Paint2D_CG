﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpGL;
namespace _19127451_Lab03
{
    public partial class Hexagon:Shape
    {
        Point centerPoint;
        List<Point> pointList = new List<Point>();
        public Point calSymetricStartPoint(Point p1)
        {
            p1.X = this.sPoint.X;
            p1.Y = this.ePoint.Y;
            return p1;
        }
        public Point calSymetricEndPoint(Point p2)
        {
            p2.X = this.ePoint.X;
            p2.Y = this.sPoint.Y;
            return p2;
        }
        public int getR()
        {
            int r = (int)Math.Sqrt(Math.Pow(ePoint.X - sPoint.X, 2) + Math.Pow(ePoint.Y - sPoint.Y, 2)) / 2;
            return r;
        }
        public Point getCenterPoint()
        {
            centerPoint.X = (sPoint.X + ePoint.X) / 2;
            centerPoint.Y = (sPoint.Y + ePoint.Y) / 2;
            return centerPoint;
        }
        private double convertSinCos(int degres, int type)
        {
            double radians = Math.PI * degres / 180.0;
            if (type == 1)
            {
                double cos = Math.Cos(radians);
                return cos;
            }
            else if (type == 2)
            {
                double sin = Math.Round(Math.Sin(radians), 2);
                return sin;
            }
            else return 0;
        }
        public Hexagon(Point start, Point end, float strokeSize, Color c)
        {
            this.sPoint = start;
            this.ePoint = end;
            int R = this.getR();
            this.centerPoint = getCenterPoint();

            for (int i = 0; i < 6; i++)
            {
                int degres = 30 + 60 * i;
                float x = (float)(R * convertSinCos(degres, 1));   // cos
                float y = (float)(R * convertSinCos(degres, 2));  // sin
                pointList.Add(new Point((int)x + centerPoint.X, (int)y + centerPoint.Y));
            }
            Line line1 = new Line(pointList[0], pointList[1], strokeSize, c);
            Line line2 = new Line(pointList[1], pointList[2], strokeSize, c);
            Line line3 = new Line(pointList[2], pointList[3], strokeSize, c);
            Line line4 = new Line(pointList[3], pointList[4], strokeSize, c);
            Line line5 = new Line(pointList[4], pointList[5], strokeSize, c);
            Line line6 = new Line(pointList[5], pointList[0], strokeSize, c);

            rasterPoints.AddRange(line1.rasterPoints);
            rasterPoints.AddRange(line2.rasterPoints);
            rasterPoints.AddRange(line3.rasterPoints);
            rasterPoints.AddRange(line4.rasterPoints);
            rasterPoints.AddRange(line5.rasterPoints);
            rasterPoints.AddRange(line6.rasterPoints);
        }
        public override void showHighLight(OpenGL gl, Point clickedPoint)
        {
            for (int i = 0; i < rasterPoints.Count; i++)
            {
                if (distance(clickedPoint, rasterPoints[i]) <= Epsilon)
                {
                    hightLightCheck = true;
                    for (int j = 0; j < 6; j++)
                    {
                        hlPoint.Add(new Point(pointList[j].X, pointList[j].Y));
                    }
                    pointList.Clear();
                    return;
                }
            }
        }
    }
}
