﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19127451_Lab03
{
    public partial class Ellipse: Shape
    {
        Point center = new Point();
        int rX, rY;
        public Point getCenterPoint()
        {
            center.X = Math.Abs((this.sPoint.X + this.ePoint.X) / 2);
            center.Y = Math.Abs((this.sPoint.Y + this.ePoint.Y) / 2);
            return this.center;
        }
        public int getMinorAxis()
        {
            rY = Math.Abs(this.sPoint.Y - this.ePoint.Y) / 2;
            return this.rY;
        }
        public int getMajorAxis()
        {
            rX = Math.Abs(this.ePoint.X - this.sPoint.X) / 2;
            return this.rX;
        }

        public  Ellipse(Point start,Point end, float strokeSize, Color c)
        {
            this.sPoint = start;
            this.ePoint = end;

            // calculate all the constants value
            Point centerPoint = new Point();
            centerPoint = this.getCenterPoint();
            int rX = this.getMajorAxis();
            int rY = this.getMinorAxis();
            Point firstPoint = new Point(0, rY);
            double squareRY = Math.Pow(rY, 2);
            double squareRX = Math.Pow(rX, 2);
            double twiceRy = 2 * squareRY * firstPoint.X;
            double twiceRx = 2 * squareRX * firstPoint.Y;
            float p = (float)(squareRY - squareRX * rY + (float)(1 / 4 * squareRX));
           
            rasterPoints.Add(new Point(centerPoint.X, centerPoint.Y + rY));
            rasterPoints.Add(new Point(centerPoint.X, centerPoint.Y - rY));
            rasterPoints.Add(new Point(centerPoint.X + rX, centerPoint.Y));
            rasterPoints.Add(new Point(centerPoint.X - rX, centerPoint.Y));

            while (twiceRy < twiceRx)
            {
                if (p < 0)
                {
                    twiceRy += 2 * squareRY;
                    p += (float)(twiceRy + squareRY);
                    firstPoint.X += 1;
                }
                else
                {
                    firstPoint.Y -= 1;
                    twiceRy += 2 * squareRY;
                    twiceRx -= 2 * squareRX;
                    p += (float)(twiceRy - twiceRx + squareRY);
                    firstPoint.X += 1;
                }
                // draw the calculated points
                rasterPoints.Add(new Point(centerPoint.X + firstPoint.X, centerPoint.Y + firstPoint.Y));
                rasterPoints.Add(new Point(centerPoint.X + firstPoint.X, centerPoint.Y - firstPoint.Y));
                rasterPoints.Add(new Point(centerPoint.X - firstPoint.X, centerPoint.Y - firstPoint.Y));
                rasterPoints.Add(new Point(centerPoint.X - firstPoint.X, centerPoint.Y + firstPoint.Y));
            }

            // for the second 
            double twiceRxLast = 2 * squareRX * firstPoint.Y;
            double twiceRyLast = 2 * squareRY * firstPoint.X;
            float p2 = (float)(squareRY * (float)Math.Pow(firstPoint.X + 1 / 2, 2) + squareRX * Math.Pow(firstPoint.Y - 1, 2) - squareRX * squareRY);
            while (firstPoint.Y != 0)
            {
                if (p2 > 0)
                {
                    twiceRxLast = twiceRxLast - 2 * squareRX;
                    p2 = (float)(p2 - twiceRxLast + squareRX);
                    firstPoint.Y -= 1;
                }
                else
                {
                    twiceRyLast = twiceRyLast + 2 * squareRY;
                    twiceRxLast = twiceRxLast - 2 * squareRX;
                    p2 = (float)(p2 + twiceRyLast - twiceRxLast + squareRX);
                    firstPoint.X += 1;
                    firstPoint.Y -= 1;
                }
                rasterPoints.Add(new Point(centerPoint.X + firstPoint.X, centerPoint.Y + firstPoint.Y));
                rasterPoints.Add(new Point(centerPoint.X + firstPoint.X, centerPoint.Y - firstPoint.Y));
                rasterPoints.Add(new Point(centerPoint.X - firstPoint.X, centerPoint.Y - firstPoint.Y));
                rasterPoints.Add(new Point(centerPoint.X - firstPoint.X, centerPoint.Y + firstPoint.Y));
            }
         
        }
        public override void showHighLight(OpenGL gl, Point clickedPoint)
        {
            for (int i = 0; i < rasterPoints.Count; i++)
            {
                if (distance(clickedPoint, rasterPoints[i]) <= Epsilon)
                {
                    hightLightCheck = true;
                    hlPoint.Add(new Point(center.X - this.getMajorAxis(),center.Y));
                   hlPoint.Add(new Point(center.X - this.getMajorAxis(), center.Y - this.getMinorAxis()));
                   hlPoint.Add(new Point(center.X - this.getMajorAxis(), center.Y + this.getMinorAxis()));
                   hlPoint.Add(new Point(center.X, center.Y - this.getMinorAxis()));
                   hlPoint.Add(new Point(center.X,center.Y + this.getMinorAxis()));
                   hlPoint.Add(new Point(center.X + this.getMajorAxis(),center.Y - this.getMinorAxis()));
                   hlPoint.Add(new Point(center.X + this.getMajorAxis(),  center.Y));
                   hlPoint.Add(new Point(center.X + this.getMajorAxis(), center.Y + this.getMinorAxis()));
                    return;
                }
            }
        }
    }
}
