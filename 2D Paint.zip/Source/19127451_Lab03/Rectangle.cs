﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19127451_Lab03
{
    public partial class Rectangle: Shape
    {
        Point symStart ;
        Point symEnd; 
        public Point calSymetricStartPoint(Point p1)
        {
            p1.X = this.sPoint.X;
            p1.Y = this.ePoint.Y;
            return p1;
        }
        public Point calSymetricEndPoint(Point p2)
        {
            p2.X = this.ePoint.X;
            p2.Y = this.sPoint.Y;
            return p2;
        }
        public void setSymetricPoints(Point symS, Point symE)
        {
            this.symStart = symS;
            this.symEnd = symE;
        }

        public Point getStartPoint()
        {
            return this.sPoint;
        }
        public Point getEndPoint()
        {
            return this.ePoint;
        }
        public Point getSymetricStart()
        {
            return this.symStart;
        }
        public Point getSymetricEnd()
        {
            return this.symEnd;
        }
        public Rectangle(Point start, Point end, float strokeSize, Color c)
        {
            this.sPoint = start;
            this.ePoint = end;
            this.symStart = this.calSymetricStartPoint(symStart);
            this.symEnd = this.calSymetricEndPoint(symEnd);
            Line line1 = new Line(start, symEnd, strokeSize, c);
            Line line2 = new Line(symEnd, end, strokeSize, c);
            Line line3 = new Line(end, symStart, strokeSize, c);
            Line line4 = new Line(symStart, start, strokeSize, c);
            rasterPoints.AddRange(line1.rasterPoints);
            rasterPoints.AddRange(line2.rasterPoints);
            rasterPoints.AddRange(line3.rasterPoints);
            rasterPoints.AddRange(line4.rasterPoints);
        }
        public override void showHighLight(OpenGL gl, Point clickedPoint)
        {
            for (int i = 0; i < rasterPoints.Count; i++)
            {
                if (distance(clickedPoint, rasterPoints[i]) <= Epsilon)
                {
                    hightLightCheck = true;
                    hlPoint.Add(new Point(sPoint.X, sPoint.Y));
                    hlPoint.Add(new Point(ePoint.X, ePoint.Y));
                    hlPoint.Add(new Point(sPoint.X, ePoint.Y));
                    hlPoint.Add(new Point(ePoint.X, sPoint.Y));

                    hlPoint.Add(new Point(sPoint.X, (sPoint.Y + symStart.Y) / 2));
                    hlPoint.Add(new Point(ePoint.X, (ePoint.Y + symEnd.Y) / 2));
                    hlPoint.Add(new Point((sPoint.X + symEnd.X) / 2, sPoint.Y));
                    hlPoint.Add(new Point((ePoint.X + symStart.X) / 2, ePoint.Y));
                    return;
                }
            }
        }
    }
}
