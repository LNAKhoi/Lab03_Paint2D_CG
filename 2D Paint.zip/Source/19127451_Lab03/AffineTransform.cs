﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19127451_Lab03
{
    public partial class AffineTransform:Shape
    {
        List<double> transMat;
        // khởi tạo ma trận transform là ma trận đơn vị
        /*
            [1,0,0]
            [0,1,0]
            [0,0,1]
         */
        public AffineTransform()
        {
            this.transMat = new List<double> { 1,0,0,
                                               0,1,0,
                                               0,0,1};
        }
        // hàm biến đổi
        public Point Transform(Point p)
        {
            /*
             
                Affine matrix* firstP = resultP
                     [1,0,0]    [pX]    [p'X]
                     [0,1,0]  * [pY] =  [p'Y]
                     [0,0,1]    [1.0]   [1.0]
                với pX pY là vị trí ban đầu, p'X, p'Y là vị trí sau khi biến đổi
             */

            List<double> firstPoint = new List<double> { p.X, p.Y, 1.0 };
            List<double> resultPoint = new List<double> { 0, 0, 0 };
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    resultPoint[i] += this.transMat[i * 3 + j] * firstPoint[j];
            Point newPoint = new Point();
            newPoint.X = (int)Math.Round(resultPoint[0]);
            newPoint.Y = (int)Math.Round(resultPoint[1]);
            return newPoint;
        }
      
        // hàm nhân ma trận
        public void multiMatrix(List<double> matrix)
        {
            List<double> retMatrix = new List<double> { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    for (int k = 0; k < 3; k++)
                        retMatrix[i * 3 + j] += matrix[i * 3 + k] * transMat[k * 3 + j];
            transMat = retMatrix;
        }
        // hàm dịch chuyển
        public void Translate(double dx, double dy)
        {
           
            /*
             * Khởi tạo ma trận translate dạng:
                [1,0,dx]
                [0,1,dy]
                [0,0,1]
                dx dy là độ dời
             */

            List<double> transformMatrix = new List<double> { 1, 0, dx,
                                                              0, 1, dy, 
                                                              0, 0, 1 };
            multiMatrix(transformMatrix);
        }

        // hàm zoom - scale
        public void Scale(double sx, double sy)
        {
            //  Khởi tạo ma trận scale dạng:
            /*
                [sx,0,0]
                [0,sy,0]
                [0,0,1]
             */
            List<double> scaleMat = new List<double> { sx, 0, 0,
                                                              0, sy, 0, 
                                                              0, 0, 1 };
            multiMatrix(scaleMat);
        }
        public void Rotate(double angle)
        {
            // Khởi tạo ma trận xoay dạng
            /*
                [cos(a),-sin(a),0]
                [sin(a),cos(a),0]
                [0,0,1]
             */
            double cosAngle = Math.Cos(angle);
            double sinAngle = Math.Sin(angle);
            List<double> rotateMat = new List<double> { cosAngle, -sinAngle, 0,
                                                           sinAngle, cosAngle, 0, 
                                                           0, 0, 1 };
            multiMatrix(rotateMat);
        }
    }
}
