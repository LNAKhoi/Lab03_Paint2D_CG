﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpGL;
namespace _19127451_Lab03
{
    public partial class Polygon:Shape
    {
        public List<Point> listPoint;
        Point centerPoint;
        AffineTransform affine = new AffineTransform();
        public Polygon(List<Point> x) {
            listPoint= new List<Point>(x);
        }
        public void setList(Point point) { 
            this.listPoint.Add(point);  
        }
        public override List<Point> DrawShape(OpenGL gl, float strokeSize)
        {
           
            // nối các điểm lại với nhau
            for (int i = 0; i < listPoint.Count - 1; i++)
            {
                Line line = new Line(listPoint[i], listPoint[i + 1], strokeSize, c);
                line.DrawShape(gl, strokeSize);
                rasterPoints.AddRange(line.DrawShape(gl, strokeSize));
            }
            // check nếu có 3 điểm thì tự động nối điểm cuối với đầu
            if (listPoint.Count >= 3)
            {
                Line line = new Line(listPoint[0], listPoint[listPoint.Count - 1], strokeSize, c);
                line.DrawShape(gl, strokeSize);
                rasterPoints.AddRange(line.DrawShape(gl, strokeSize));
            }
            // vẽ highlight
            if (hightLightCheck == true)
            {
                gl.Color(c.R / 255.0, c.G / 255.0, c.B / 255.0, 0);
                gl.PointSize(8);
                gl.Begin(OpenGL.GL_POINTS);
                for (int i = 0; i < hlPoint.Count; i++)
                {
                    gl.Vertex(hlPoint[i].X, gl.RenderContextProvider.Height - hlPoint[i].Y);
                }
                gl.End();
                gl.Flush();
            }
            return rasterPoints;
        }
        // check highlight
        public override void showHighLight(OpenGL gl, Point clickedPoint)
        {
            for (int i = 0; i < rasterPoints.Count; i++)
            {
                if (distance(clickedPoint, rasterPoints[i]) <= Epsilon)
                {
                    hightLightCheck = true;
                    for (int j = 0; j < listPoint.Count; j++)
                    {
                        hlPoint.Add(new Point(listPoint[j].X,listPoint[j].Y));
                    }
                    return;
                }
            }
        }
        public override void TranslateShape(Point start, Point end)
        {
             affine = new AffineTransform();
            // dời vị trí điểm đầu, điểm cuối
            affine.Translate(end.X - start.X, end.Y - start.Y);
            for (int i = 0; i < listPoint.Count; i++)
            {
                // dời vị trí các điểm vẽ hình
                listPoint[i] = affine.Transform(listPoint[i]);
                // nếu có bật điểm highlight thì dời điểm highlight
                if (hightLightCheck == true && i < hlPoint.Count)
                {
                    hlPoint[i] = affine.Transform(hlPoint[i]);
                }
            }
            // biến đổi 2 điểm đầu cuối.
            start = affine.Transform(start);
            end = affine.Transform(end);
        }
        public override void ZoomShape(Point start, Point end)
        {
            affine = new AffineTransform();
            for (int i = 0; i < listPoint.Count; i++) { 
                centerPoint.X+=listPoint[i].X;  
                centerPoint.Y+=listPoint[i].Y;  
            }
            centerPoint.X/=listPoint.Count;
            centerPoint.Y/=listPoint.Count;
            // tính sx,sy
            double sx = (double)(end.X - centerPoint.X) / (double)(start.X - centerPoint.X);
            double sy = (double)(end.Y - centerPoint.Y) / (double)(start.Y - centerPoint.Y);
            // dời điểm đầu
            affine.Translate(-centerPoint.X, -centerPoint.Y);
            // scale lại điểm 
            affine.Scale(sx, sy);
            // dời về chỗ cũ
            affine.Translate(centerPoint.X, centerPoint.Y);
            for (int i = 0; i < listPoint.Count; i++)
            {
                // dời vị trí các điểm vẽ hình
                listPoint[i] = affine.Transform(listPoint[i]);
                // nếu có bật điểm highlight thì dời điểm highlight
                if (hightLightCheck == true && i < hlPoint.Count)
                {
                    hlPoint[i] = affine.Transform(hlPoint[i]);
                }
            }
            // biến đổi 2 điểm đầu cuối.
            start = affine.Transform(start);
            end = affine.Transform(end);
        }
        public override void RotateShape(Point Start, Point End)
        {
            for (int i = 0; i < listPoint.Count; i++)
            {
                centerPoint.X += listPoint[i].X;
                centerPoint.Y += listPoint[i].Y;
            }
            centerPoint.X /= listPoint.Count;
            centerPoint.Y /= listPoint.Count;
            affine = new AffineTransform();
            Point newStart = new Point(Start.X - centerPoint.X, Start.Y - centerPoint.Y);
            Point newEnd = new Point(End.X - centerPoint.X, End.Y - centerPoint.Y);
            // tính khoảng cách thay đổi
            double newStartDistance = distance(centerPoint, Start);
            double newEndDistance = distance(centerPoint, End);
            // tính góc
            double angle = newStart.X * newEnd.X + newStart.Y * newEnd.Y;
            angle /= newStartDistance * newEndDistance;
            // chuyển sang arcCos
            double theta = Math.Acos(angle);
            if (newStart.X * newEnd.Y - newStart.Y * newEnd.X < 0)
                theta *= -1;
            // bắt đầu biến đổi
            affine.Translate(-centerPoint.X, -centerPoint.Y);
            affine.Rotate(theta);
            affine.Translate(centerPoint.X, centerPoint.Y);
            // biến đổi các điểm vẽ và highlight
            for (int i = 0; i <listPoint.Count; i++)
            {
                listPoint[i] = affine.Transform(listPoint[i]);
                if (i < hlPoint.Count)
                    hlPoint[i] = affine.Transform(hlPoint[i]);
            }
            Start = affine.Transform(Start);
            End = affine.Transform(End);
        }
    }
}
