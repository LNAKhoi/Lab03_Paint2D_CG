﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19127451_Lab03
{
    public partial class Circle:Shape
    {
        public int getR() {
            int R = (int)Math.Sqrt(Math.Pow((sPoint.X - ePoint.X), 2) + Math.Pow((sPoint.Y - ePoint.Y), 2));
            return R;
        }
      
        // Draw the circle
        public Circle(Point center,Point end,float strokeSize, Color c)
        {
            sPoint = center;
            ePoint = end;   
            Point firstPoint = new Point(0, this.getR());
            // Calculate the constants values
            int twiceX, twiceY, p;
            // get circle center points
            int xC = this.sPoint.X;
            int yC = this.sPoint.Y;
            // calculate delta x, delta y and p
            twiceX = 2 * firstPoint.X;
            twiceY = 2 * firstPoint.Y;
            // assume that R is an integer
            p = 1 - this.getR();
            // call the 8 points function to draw 8 points
            rasterPoints.Add(new Point(xC + firstPoint.X, yC + firstPoint.Y));
            rasterPoints.Add(new Point(xC + firstPoint.Y, yC + firstPoint.X));
            rasterPoints.Add(new Point(xC + firstPoint.Y, yC - firstPoint.X));
            rasterPoints.Add(new Point(xC + firstPoint.X, yC - firstPoint.Y));
            rasterPoints.Add(new Point(xC - firstPoint.X, yC - firstPoint.Y));
            rasterPoints.Add(new Point(xC - firstPoint.Y, yC - firstPoint.X));
            rasterPoints.Add(new Point(xC - firstPoint.Y, yC + firstPoint.X));
            rasterPoints.Add(new Point(xC - firstPoint.X, yC + firstPoint.Y));

            while (firstPoint.X < firstPoint.Y)
            {
                if (p < 0)
                {
                    twiceX += 2;
                    p += twiceX + 1;
                }
                else if (p >= 0)
                {
                    twiceX += 2;
                    twiceY -= 2;
                    p += twiceX - twiceY + 1;
                    firstPoint.Y -= 1;
                }
                firstPoint.X += 1;

                rasterPoints.Add(new Point(xC + firstPoint.X, yC + firstPoint.Y));
                rasterPoints.Add(new Point(xC + firstPoint.Y, yC + firstPoint.X));
                rasterPoints.Add(new Point(xC + firstPoint.Y, yC - firstPoint.X));
                rasterPoints.Add(new Point(xC + firstPoint.X, yC - firstPoint.Y));
                rasterPoints.Add(new Point(xC - firstPoint.X, yC - firstPoint.Y));
                rasterPoints.Add(new Point(xC - firstPoint.Y, yC - firstPoint.X));
                rasterPoints.Add(new Point(xC - firstPoint.Y, yC + firstPoint.X));
                rasterPoints.Add(new Point(xC - firstPoint.X, yC + firstPoint.Y));
            }
         
        }
        public override void showHighLight(OpenGL gl, Point clickedPoint)
        {
            int Radius = this.getR();
            for (int i = 0; i < rasterPoints.Count; i++)
            {
                if (distance(clickedPoint, rasterPoints[i]) <= Epsilon)
                {
                    hightLightCheck = true;
                    hlPoint.Add(new Point(sPoint.X, (sPoint.Y + Radius)));
                    hlPoint.Add(new Point(sPoint.X, (sPoint.Y - Radius)));
                    hlPoint.Add(new Point(sPoint.X + Radius, sPoint.Y));
                    hlPoint.Add(new Point((sPoint.X - Radius), sPoint.Y));
                    hlPoint.Add(new Point(sPoint.X + Radius, (sPoint.Y - Radius)));
                    hlPoint.Add(new Point(sPoint.X - Radius, (sPoint.Y - Radius)));
                    hlPoint.Add(new Point(sPoint.X + Radius, (sPoint.Y + Radius)));
                    hlPoint.Add(new Point(sPoint.X - Radius, (sPoint.Y + Radius)));
                    return;
                }
            }
        }
    }
}
